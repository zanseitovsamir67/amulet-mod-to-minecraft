package com.example.amuletmod.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class AmuletItem extends Item {

    public AmuletItem(Settings settings) {
        super(settings.maxCount(1));
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        // glow if at least one stat upgraded
        for (String stat : AmuletData.STATS) {
            if (AmuletData.getLevel(stack, stat) > 0) return true;
        }
        return false;
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        super.appendTooltip(stack, world, tooltip, context);
        tooltip.add(Text.translatable("item.amuletmod.amulet.tooltip").formatted(Formatting.GRAY));
        for (int i = 0; i < AmuletData.STATS.length; i++) {
            int lvl = AmuletData.getLevel(stack, AmuletData.STATS[i]);
            if (lvl > 0) {
                tooltip.add(Text.literal(AmuletData.STAT_NAMES_RU[i] + ": +" + lvl)
                        .formatted(Formatting.AQUA));
            }
        }
    }
}

package com.example.amuletmod.item;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

/**
 * Helper for reading/writing amulet stat levels to NBT.
 * Stats: speed, damage, armor, hp, range, attack_speed, regen, hunger_reduction.
 */
public class AmuletData {

    public static final String[] STATS = {
            "speed", "damage", "armor", "hp",
            "range", "attack_speed", "regen", "hunger_reduction"
    };

    public static final String[] STAT_NAMES_RU = {
            "Скорость", "Урон", "Броня", "Здоровье",
            "Дальность", "Скорость атаки", "Регенерация", "Снижение голода"
    };

    public static final int MAX_LEVEL = 50;

    public static int getLevel(ItemStack stack, String stat) {
        NbtCompound nbt = stack.getNbt();
        if (nbt == null) return 0;
        return nbt.getInt("amulet_" + stat);
    }

    public static void setLevel(ItemStack stack, String stat, int level) {
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putInt("amulet_" + stat, Math.max(0, Math.min(level, MAX_LEVEL)));
    }

    public static boolean upgrade(ItemStack stack, int statIndex) {
        if (statIndex < 0 || statIndex >= STATS.length) return false;
        int cur = getLevel(stack, STATS[statIndex]);
        if (cur >= MAX_LEVEL) return false;
        setLevel(stack, STATS[statIndex], cur + 1);
        return true;
    }

    /** Copies all stat levels from src to dst (used in anvil recipe). */
    public static void copyStats(ItemStack src, ItemStack dst) {
        for (String stat : STATS) {
            int lvl = getLevel(src, stat);
            if (lvl > 0) setLevel(dst, stat, lvl);
        }
        // copy cooldown too if present
        NbtCompound srcNbt = src.getNbt();
        if (srcNbt != null && srcNbt.contains("amulet_totem_cd")) {
            dst.getOrCreateNbt().putLong("amulet_totem_cd", srcNbt.getLong("amulet_totem_cd"));
        }
    }
}

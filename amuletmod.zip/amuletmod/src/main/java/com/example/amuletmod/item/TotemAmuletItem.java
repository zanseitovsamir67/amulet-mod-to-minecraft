package com.example.amuletmod.item;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class TotemAmuletItem extends AmuletItem {

    /** 5 minutes in ticks. */
    public static final long COOLDOWN_TICKS = 6000L;

    public TotemAmuletItem(Settings settings) {
        super(settings);
    }

    public static boolean isReady(ItemStack stack, long currentTime) {
        NbtCompound nbt = stack.getNbt();
        if (nbt == null) return true;
        long last = nbt.getLong("amulet_totem_cd");
        return last == 0 || currentTime - last >= COOLDOWN_TICKS;
    }

    public static void triggerCooldown(ItemStack stack, long currentTime) {
        stack.getOrCreateNbt().putLong("amulet_totem_cd", currentTime);
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.translatable("item.amuletmod.totem_amulet.tooltip1").formatted(Formatting.GOLD));
        tooltip.add(Text.translatable("item.amuletmod.totem_amulet.tooltip2").formatted(Formatting.GRAY));
        for (int i = 0; i < AmuletData.STATS.length; i++) {
            int lvl = AmuletData.getLevel(stack, AmuletData.STATS[i]);
            if (lvl > 0) {
                tooltip.add(Text.literal(AmuletData.STAT_NAMES_RU[i] + ": +" + lvl)
                        .formatted(Formatting.AQUA));
            }
        }
        if (world != null) {
            long now = world.getTime();
            if (!isReady(stack, now)) {
                long left = COOLDOWN_TICKS - (now - stack.getOrCreateNbt().getLong("amulet_totem_cd"));
                tooltip.add(Text.literal("§cПерезарядка: " + (left / 20) + " сек."));
            } else {
                tooltip.add(Text.literal("§aГотов к использованию"));
            }
        }
    }
}
